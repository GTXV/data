# NexusTrader 交易引擎 (`Engine`) 设计详解

`nexustrader/engine.py` 中的 `Engine` 类是整个 NexusTrader 交易系统的核心，它扮演着“指挥官”的角色，负责初始化、组装、启动和停止所有交易组件。本文档将详细解析其设计理念、核心职责和工作流程。

---

## 1. 核心设计理念

`Engine` 的设计遵循以下几个核心原则：

*   **配置驱动 (Configuration-Driven)**：引擎的所有行为，包括连接哪个交易所、使用什么账户、加载哪个策略等，都由一个统一的 `Config` 对象定义。这使得交易逻辑与具体配置分离，易于管理和切换。
*   **组件化与依赖注入 (Componentization & Dependency Injection)**：系统被拆分为多个独立的组件（如 `Connector`, `EMS`, `OMS`, `Cache` 等）。`Engine` 负责创建这些组件，并将它们（作为依赖）注入到需要它们的其他组件中（例如，将 `EMS` 和 `Cache` 注入到 `Strategy` 中）。这降低了组件间的耦合度，提高了代码的可测试性和可维护性。
*   **事件驱动架构 (Event-Driven Architecture)**：引擎内置了一个高性能的 `MsgBus` (消息总线)，来自底层的 `Nautilus-Core` (Rust 实现)。组件之间通过发布和订阅事件进行通信，而不是直接调用。例如，`Connector` 收到交易所的订单更新后，会发布一个事件，`OMS` 和 `Strategy` 可以订阅该事件并做出响应。这实现了完美的关注点分离。
*   **异步I/O优先 (Async I/O First)**：交易系统涉及大量的网络I/O（REST请求、WebSocket数据流）。`Engine` 基于 `asyncio` 构建，并默认在非Windows系统上使用 `uvloop` 策略，以实现高并发和低延迟的网络通信处理。
*   **生命周期管理 (Lifecycle Management)**：`Engine` 精确控制所有组件的启动、运行和停止顺序，确保资源（如网络连接、数据库）能够被正确初始化和优雅地释放。

---

## 2. `Engine` 的主要职责

`Engine` 的职责可以归纳为以下几点：

1.  **环境设置**：根据操作系统设置最优的 `asyncio` 事件循环策略（如 `uvloop`）。
2.  **核心组件初始化**：
    *   初始化基于Rust的 `Nautilus-Core`，获取 `Logger` (日志), `MsgBus` (消息总线), 和 `Clock` (时钟)。
    *   创建 `TaskManager` 来管理所有的 `asyncio` 任务。
    *   创建 `AsyncCache` 用于缓存市场数据、订单、持仓等状态。
    *   创建 `OrderRegistry` 用于在内存中快速跟踪和管理订单。
3.  **交易组件构建 (`_build` 流程)**：
    *   根据配置创建各个交易所的 `ExchangeManager`。
    *   构建 `PublicConnector` (公共连接器)，用于订阅行情、订单簿等公开市场数据。
    *   构建 `PrivateConnector` (私有连接器)，用于下单、查询余额、持仓等需要身份验证的操作。支持**实盘**和**模拟** (`Mock`) 两种模式。
    *   构建 `EMS` (Execution Management System, 执行管理系统)，封装下单、改单、撤单的逻辑。
    *   构建 `OMS` (Order Management System, 订单管理系统)，负责跟踪和管理订单的完整生命周期状态。
4.  **策略初始化**：
    *   实例化用户定义的 `Strategy` 类。
    *   将 `Cache`, `MsgBus`, `EMS` 等核心服务注入到策略实例中，为策略提供与系统交互的接口。
5.  **生命周期控制**：
    *   **`start()`**: 启动整个引擎，包括连接交易所、订阅数据、启动策略的定时任务等。
    *   **`dispose()`**: 优雅地关闭引擎，包括停止策略、断开连接、取消所有任务、刷新日志和关闭事件循环。

---

## 3. 工作流程与生命周期

`Engine` 的工作流程可以分为**构建 (Build)**、**启动 (Start)** 和 **销毁 (Dispose)** 三个阶段。

### 阶段一：构建 (`_build`)

当 `engine.start()` 被调用时，首先会执行内部的 `_build()` 方法。

1.  `_build_exchanges()`: 根据 `config.basic_config` 创建 `BybitExchangeManager`, `BinanceExchangeManager` 等实例。这些管理器封装了交易所特有的API客户端和配置。
2.  `_build_public_connectors()`: 根据 `config.public_conn_config` 创建用于连接公共WebSocket频道的连接器。
3.  `_build_private_connectors()`: 根据 `config.private_conn_config` 创建用于私有API交互的连接器。如果 `config.is_mock` 为 `True`，则会创建 `MockLinearConnector` 等模拟连接器，否则创建真实的 `BybitPrivateConnector` 等。
4.  `_build_ems()` 和 `_build_oms()`: 为每个交易所创建对应的执行和订单管理系统。这些系统会监听 `MsgBus` 上的事件来工作。
5.  `_build_custom_signal_recv()`: 如果配置了 `zero_mq_signal_config`，则会创建一个ZeroMQ接收器，允许策略通过外部信号触发 (`on_custom_signal`)。

### 阶段二：启动 (`_start`)

构建完成后，`start()` 方法会调用异步的 `_start()` 方法来启动所有服务。

1.  `_start_oms()` 和 `_start_ems()`: 启动订单和执行管理系统，让它们开始监听消息总线。
2.  `_start_connectors()`:
    *   调用所有 `PrivateConnector` 的 `connect()` 方法，建立与交易所的私有WebSocket连接并进行认证。
    *   根据策略中定义的订阅（`strategy._subscriptions`），调用 `PublicConnector` 的 `subscribe_*` 方法（如 `subscribe_bookl1`, `subscribe_trade`）来订阅市场数据。
3.  `_start_scheduler()`: 启动策略内部的 `apscheduler`，用于执行 `on_bar`, `on_tick` 等定时或周期性任务。
4.  `_start_auto_flush_thread()`: 启动一个独立的线程，用于周期性地将日志从内存缓冲区刷新到文件，防止日志丢失。
5.  `_task_manager.wait()`: 引擎进入主运行循环，等待所有后台任务（如WebSocket心跳、数据处理等）完成。程序会在此阻塞，直到 `dispose()` 被调用。

### 阶段三：销毁 (`_dispose`)

当程序需要退出时，`dispose()` 方法被调用，以确保所有资源被安全释放。

1.  `_strategy._scheduler.shutdown()`: 停止策略的调度器，不再产生新的事件。
2.  `_auto_flush_stop_event.set()`: 停止日志自动刷新线程。
3.  `connector.disconnect()`: 断开所有与交易所的WebSocket连接。
4.  `_task_manager.cancel()`: 取消所有正在运行的 `asyncio` 任务。
5.  `_cache.close()`: 关闭缓存，确保所有数据都已同步到持久化存储（如数据库）。
6.  `_loop.close()`: 关闭 `asyncio` 事件循环。
7.  `nautilus_pyo3.logger_flush()`: 最后一次强制刷新日志，确保所有日志都已写入文件。

---

## 4. 架构图

下面是一个简化的架构图，展示了 `Engine` 如何将各个组件连接在一起：

```
+-------------------------------------------------------------------+ 
|                              Engine                               | 
|                                                                   | 
|  +-----------------+     +-------------------------------------+  | 
|  |     Config      |---->|          Build Process              |  | 
|  +-----------------+     | (Creates & Wires all components)    |  | 
|                          +-------------------------------------+  | 
|                                      |                            | 
|                                      v                            | 
|  +---------------------------------------------------------------+  | 
|  |                       Nautilus-Core (Rust)                    |  | 
|  |                                                               |  | 
|  |  +-----------+      +-------------+      +----------------+  |  | 
|  |  |   Clock   |<---->|   MsgBus    |<---->|     Logger     |  |  | 
|  |  +-----------+      +-------------+      +----------------+  |  | 
|  |                           ^     ^                            |  | 
|  +---------------------------|-----|----------------------------+  | 
|                              |     |                              | 
|  +---------------------------+-----|----------------------------+  | 
|  |      Python Components (Managed by TaskManager)             |  | 
|  |                              |     |                          |  | 
|  |  +----------+   (Injects)   +-----------+  (Subscribes)  +---+  | 
|  |  | Strategy |<--------------|    EMS    |<---------------|OMS|  | 
|  |  +----------+               +-----------+                +---+  | 
|  |    ^   ^   ^                      ^                          |  | 
|  |    |   |   |                      |                          |  | 
|  | (Injects) |                      | (Uses)                   |  | 
|  |    |   |   |                      |                          |  | 
|  |  +-----+----+               +----+-----+               +----+  | 
|  |  |  Cache   |               | Private  |               |Public|  | 
|  |  +----------+               | Connector|               |Conn. |  | 
|  |       ^                     +----------+               +------+  | 
|  |       |                           ^                          ^  | 
|  |       +---------------------------+--------------------------+  | 
|  |                                   |                          |  | 
|  +---------------------------------------------------------------+  | 
|                                      v                          v  | 
+-------------------------------------------------------------------+ 
                               +----------------+     +----------------+ 
                               | Exchange API 1 |     | Exchange API 2 | 
                               +----------------+     +----------------+ 
```