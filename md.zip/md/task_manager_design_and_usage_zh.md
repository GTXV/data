# NexusTrader `TaskManager` 设计与使用详解

### 1. 问题背景：“即发即忘”的异步任务

在任何复杂的异步应用中，我们经常需要运行一些与程序生命周期一样长的后台进程。例如：
*   一个监听消息的 WebSocket 客户端。
*   一个每分钟将数据同步到数据库的周期性任务。
*   一个维持网络连接的心跳机制。

一种简单粗暴的方法是使用 `asyncio.create_task()` 来“即发即忘”(Fire-and-Forget) 地启动这些任务。但这会导致几个严重的问题：
*   **异常丢失**：如果一个后台任务因异常而崩溃，这个错误可能会被静默地忽略掉。你的程序将在一个未知的错误状态下继续运行，而你对此一无所知。
*   **难以关闭**：当你希望优雅地停止应用时，你没有一个集中的地方来查找并取消所有这些正在运行的后台任务。
*   **缺少生命周期控制**：你无法方便地等待所有任务都准备就绪，也无法在关闭时等待它们全部完成。

`TaskManager` 的设计初衷，正是为了解决以上这些问题。

### 2. 核心设计与职责

`TaskManager` 扮演着一个**集中式的 `asyncio` 任务注册中心和生命周期管理器**的角色。

它的核心职责可以概括为：
1.  **任务注册**：提供一个统一的方法 (`create_task`) 来创建并注册后台任务。
2.  **异常处理**：确保任何在后台任务中抛出的异常都能被捕获、记录和妥善处理。
3.  **生命周期管理**：提供清晰的机制来`wait`（等待）关闭信号，以及在优雅停机过程中 `cancel`（取消）所有已注册的任务。
4.  **信号处理**：集成操作系统的信号（如 `Ctrl+C`），以启动优雅的关闭流程。

### 3. 核心方法详解

#### `__init__(self, loop, enable_signal_handlers=True)`
*   初始化时，它接收主 `asyncio` 事件循环作为参数。
*   它创建一个 `self._tasks` 字典，用于存放所有正在运行的任务的引用。
*   它创建一个 `asyncio.Event()` 对象，名为 `self._shutdown_event`。这个事件是整个应用的主“暂停”信号，引擎会一直等待这个事件，直到关闭被触发。
*   默认情况下，它会调用 `_setup_signal_handlers()` 来设置信号处理。

#### `_setup_signal_handlers()`
*   此方法为 `SIGINT`（中断信号，例如 `Ctrl+C`）和 `SIGTERM`（终止信号）这两个操作系统信号绑定了处理器。
*   当检测到任一信号时，它会触发 `_shutdown()` 协程。这是连接操作系统与应用内优雅停机逻辑的桥梁。

#### `create_task(self, coro, name=None)`
这是框架使用者最常用的方法。
*   它接收一个协程 (`coro`) 作为输入。
*   它调用 `asyncio.create_task()` 将该协程作为一个后台任务来启动。
*   它将创建的任务存放在内部的 `_tasks` 字典中，使其变为“受管理”状态。
*   **最关键的一步**：它通过 `task.add_done_callback()` 将 `_handle_task_done` 方法添加为任务完成时的回调。

#### `_handle_task_done(self, task)`
这个回调函数是实现健壮错误处理的关键。
*   无论一个受管理任务因何种原因结束（成功完成、被取消或抛出异常），`asyncio` 都会自动调用这个回调。
*   它将已完成的任务从 `_tasks` 字典中移除。
*   它调用 `task.result()`。如果任务中出现了异常，`task.result()` 会重新抛出该异常。这样，`try...except` 代码块就能捕获到这个异常并进行日志记录，从而确保**没有后台任务能够静默地失败**。

#### `wait(self)`
*   这个方法内部只有一行 `await self._shutdown_event.wait()`。
*   `Engine` 在其主 `_start` 方法中调用它。这使得整个应用会在此处无限期地运行，直到信号处理器设置了 `_shutdown_event` 事件。
*   它构成了应用的主“运行循环”。

#### `cancel(self)`
*   此方法在 `Engine` 的 `dispose`（销毁）阶段被调用。
*   它会遍历 `_tasks` 字典中所有当前正在运行的任务，并逐一调用它们的 `cancel()` 方法。
*   然后，它使用 `await asyncio.gather(...)` 来等待所有任务响应取消操作，确保一个干净、有序的关闭过程。

### 4. 在 NexusTrader 中的应用

`TaskManager` 的使用模式清晰地展示了其设计的优越性：

1.  **创建**：在 `Engine.__init__` 中，一个 `TaskManager` 单例被创建，并与主事件循环绑定。
    ```python
    self._loop = asyncio.new_event_loop()
    self._task_manager = TaskManager(self._loop)
    ```

2.  **依赖注入**：这个单例随后被作为依赖项，传入所有需要运行后台任务的核心组件中，如 `AsyncCache`, `Connectors`, `EMS`, `OMS` 等。
    ```python
    # 在 Engine 中创建其他组件时
    self._cache = AsyncCache(..., task_manager=self._task_manager)
    self._ems[exchange_id] = BybitExecutionManagementSystem(..., task_manager=self._task_manager)
    ```

3.  **使用**：各个组件使用被注入的 `task_manager` 来运行它们的后台进程。
    ```python
    # 在 AsyncCache.start() 中
    self._task_manager.create_task(self._periodic_sync())

    # 在一个 WebSocket 连接器中 (示例)
    # self._task_manager.create_task(self._heartbeat_loop())
    # self._task_manager.create_task(self._message_processing_loop())
    ```

4.  **执行与关闭**：
    *   `Engine` 调用 `await self._task_manager.wait()` 来使应用进入运行状态。
    *   当你按下 `Ctrl+C`，信号处理器调用 `_shutdown()`，它会设置事件，从而解除 `wait()` 的阻塞。
    *   `Engine` 接着执行其 `dispose` 方法，该方法会调用 `await self._task_manager.cancel()` 来干净地停止所有后台任务。

总而言之，`TaskManager` 为健壮的并发任务管理提供了一个简单而强大的抽象，构成了引擎生命周期的支柱，并确保了整个应用的稳定性。