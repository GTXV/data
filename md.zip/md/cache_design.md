# NexusTrader 缓存系统 (`AsyncCache`) 设计详解

`nexustrader/core/cache.py` 中的 `AsyncCache` 类是 NexusTrader 交易系统的核心数据中心和状态管理器。它旨在为高频的读写操作提供快速的内存访问，同时通过与持久化存储后端（如SQLite或PostgreSQL）的结合，确保策略状态（如订单、持仓、参数）在程序重启后依然能够恢复。本文档将深入剖析其设计理念、架构和工作流程。

---

## 1. 核心设计理念

`AsyncCache` 的设计围绕以下几个关键原则：

*   **混合缓存策略 (Hybrid Caching)**：系统同时使用**内存缓存**和**数据库后端**。内存缓存（In-Memory）用于存储热数据（Hot Data），如最新的市场行情、活跃的订单和持仓，以实现微秒级的快速访问。数据库则作为冷数据（Cold Data）存储和持久化层，确保数据的安全性和可恢复性。

*   **事件驱动更新 (Event-Driven Updates)**：`AsyncCache` 作为一个订阅者，监听来自 `MsgBus` (消息总线) 的各种事件。当 `Connector` 收到新的市场数据（如 `kline`, `trade`, `bookl1`）时，它会发布一个事件，`AsyncCache` 的回调函数会自动捕获这些数据并更新内存缓存。这种设计将数据接收与数据存储解耦，提高了系统的模块化程度。

*   **异步持久化 (Asynchronous Persistence)**：为了避免频繁的数据库I/O操作阻塞主事件循环，数据的持久化（从内存同步到数据库）在一个独立的后台异步任务 (`_periodic_sync`) 中周期性地执行。这确保了交易逻辑的高性能运行，同时以“最终一致性”的方式保证数据安全。

*   **线程安全 (Thread-Safety)**：尽管主要工作在 `asyncio` 事件循环中，但系统的某些部分（如外部信号处理）可能在不同线程中运行。`AsyncCache` 使用 `threading.RLock` 为不同类型的数据（订单、持仓、余额）提供独立的锁，确保在并发访问时内存数据的一致性和完整性。

*   **可插拔后端 (Pluggable Backends)**：通过定义一个统一的后端接口，`AsyncCache` 可以支持不同的数据库实现。目前已支持 `SQLite`（适用于轻量级、单文件部署）和 `PostgreSQL`（适用于更大型、高可用的部署），切换后端只需修改配置即可。

--- 

## 2. `AsyncCache` 的主要职责

1.  **缓存公开市场数据**：实时缓存来自交易所的公开数据流，包括 `Kline` (K线), `BookL1`/`BookL2` (订单簿), `Trade` (逐笔成交), `MarkPrice` (标记价格), `IndexPrice` (指数价格) 和 `FundingRate` (资金费率)。

2.  **管理私有账户数据**：跟踪和缓存所有与用户账户相关的状态，包括 `Order` (订单), `Position` (持仓), 和 `AccountBalance` (账户余额)。

3.  **状态持久化与恢复**：
    *   在后台定期将内存中的私有数据同步到数据库。
    *   在程序启动时，从数据库加载历史状态（如策略参数）。
    *   在程序关闭时，执行一次最终的、完整的同步，以防止数据丢失。

4.  **提供统一的数据访问接口**：为策略和其他组件提供简单、统一的方法（如 `get_position`, `get_order`, `kline`）来查询当前状态，无需关心数据是来自内存还是数据库。

5.  **管理策略参数**：提供一个简单的键值对存储 (`get_param`, `set_param`)，允许策略保存和恢复其内部状态或配置，使其在重启后能继续运行。

6.  **数据生命周期管理**：通过 `_cleanup_expired_data` 方法定期清理内存中陈旧、非活跃的数据（如已关闭很久的订单），防止内存无限增长。

--- 

## 3. 工作流程与数据流

`AsyncCache` 的生命周期和数据处理流程如下：

### 阶段一：初始化 (`__init__`)

*   初始化所有用于内存缓存的字典，如 `_mem_orders`, `_mem_positions`, `_kline_cache` 等。
*   为不同数据域（`order`, `position`, `balance`, `param`）创建线程锁。
*   向 `MsgBus` 注册回调函数，订阅所有需要缓存的公开数据主题（`kline`, `bookl1`, `trade` 等）。

### 阶段二：启动 (`start`)

1.  `_init_storage()`: 根据配置选择并实例化数据库后端（`SQLiteBackend` 或 `PostgreSQLBackend`），并建立数据库连接。
2.  `_load_params_from_db()`: 从数据库中加载先前保存的策略参数到内存 `_mem_params` 中。
3.  `_task_manager.create_task(_periodic_sync())`: 创建并启动核心的后台异步任务，该任务负责数据的周期性同步和清理。

### 阶段三：运行时操作

*   **数据流入（公开）**: 
    1.  `Connector` 从交易所WebSocket接收到市场数据。
    2.  `Connector` 将数据发布到 `MsgBus`。
    3.  `AsyncCache` 的回调函数（如 `_update_kline_cache`）被触发，将数据存入相应的内存字典中。

*   **数据流入（私有）**: 
    1.  `EMS` 或 `OMS` 等组件处理完一个私有操作（如创建一个新订单、更新一个持仓）。
    2.  这些组件调用 `AsyncCache` 的内部方法（如 `_order_initialized`, `_apply_position`）。
    3.  这些方法在获取锁后，更新内存中的私有数据字典（如 `_mem_orders`, `_mem_positions`）。

*   **数据同步 (`_periodic_sync`)**: 
    1.  任务按 `sync_interval`（如60秒）的间隔被唤醒。
    2.  调用后端接口（如 `_backend.sync_orders`），将内存中的 `_mem_orders` 批量写入数据库。
    3.  对 `positions`, `balances`, `params` 等执行同样的操作。
    4.  调用 `_cleanup_expired_data`，从内存中移除过期数据。

*   **数据流出（查询）**: 
    1.  `Strategy` 或其他组件调用 `cache.get_position("BTC-USDT-PERP")` 等查询方法。
    2.  方法在获取锁后，直接从内存字典（如 `_mem_positions`）中读取数据并返回。由于是内存操作，速度极快。

### 阶段四：关闭 (`close`)

*   在程序退出前被调用。
*   执行一次最终的、完整的内存到数据库的同步，确保所有在最后同步周期内发生的变化都被保存。
*   调用 `_backend.close()`，安全地关闭数据库连接。

--- 

## 4. 核心组件详解

*   **内存缓存 (`_mem_*` and `_*_cache`)**: 
    *   `_mem_*` 字典（如 `_mem_orders`）用于存储需要持久化的私有数据。
    *   `_*_cache` 字典（如 `_kline_cache`）用于存储不需要持久化的、易失性的市场数据。
    *   数据结构经过精心设计，如 `_mem_symbol_open_orders` 提供了按交易对快速查询未结订单的能力。

*   **持久化后端 (`_backend`)**: 
    *   这是一个抽象层，定义了 `start`, `close`, `sync_*`, `get_*` 等标准接口。
    *   `SQLiteBackend` 和 `PostgreSQLBackend` 是该接口的具体实现，封装了所有SQL操作和数据库连接管理。
    *   使用 `msgspec` 库进行序列化，将Python对象高效地编码为JSON字符串存入数据库，并在读取时解码回来。

*   **并发锁 (`_*_lock`)**: 
    *   `threading.RLock` (可重入锁) 允许多次进入，这在复杂的调用链中可以防止死锁。
    *   为不同类型的数据使用不同的锁，提高了并发性。例如，更新持仓不会阻塞对订单的读取。

*   **参数存储 (`_mem_params`)**: 
    *   一个简单的 `dict`，为策略提供了一个持久化的“记忆”。策略可以通过 `set_param` 保存任何可序列化的状态（如模型权重、交易计数、动态阈值），并通过 `get_param` 在下次启动时恢复，从而实现有状态的策略逻辑。