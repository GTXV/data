# 数据流分析

## 1. 市场数据流

```
WebSocket连接 → PublicConnector → MessageBus → Strategy.on_xxx() → 指标更新
```

**详细流程**：
1. **WebSocket接收**：实时接收交易所推送的市场数据
2. **数据解析**：PublicConnector解析并标准化数据格式
3. **消息分发**：通过MessageBus分发到所有订阅者
4. **策略处理**：Strategy接收数据并触发相应回调
5. **指标更新**：更新技术指标和内部状态

**关键代码示例**：
```python
# PublicConnector中的数据处理
async def _handle_trade_data(self, data):
    trade = Trade(
        exchange=self._exchange_id,
        symbol=data['symbol'],
        price=float(data['price']),
        size=float(data['size']),
        timestamp=int(data['timestamp'])
    )
    self._msgbus.send(endpoint="trade", msg=trade)

# Strategy中的数据接收
def _on_trade(self, trade: Trade):
    self.on_trade(trade)  # 用户实现
    self._update_indicators(trade)
```

## 2. 订单执行流

```
Strategy.create_order() → EMS → PrivateConnector → 交易所API → 订单状态回调
```

**详细流程**：
1. **策略决策**：Strategy根据市场数据生成交易信号
2. **订单提交**：通过EMS提交订单到执行队列
3. **风险检查**：EMS进行订单验证和风险控制
4. **API调用**：PrivateConnector执行交易所API调用
5. **状态更新**：接收订单状态变化并更新缓存

**关键代码示例**：
```python
# Strategy中创建订单
def create_order(self, symbol: str, side: OrderSide, amount: Decimal):
    order_submit = CreateOrderSubmit(
        symbol=symbol,
        side=side,
        type=OrderType.MARKET,
        amount=amount
    )
    self._ems[exchange_type]._submit_order(order_submit, SubmitType.CREATE)

# EMS中处理订单
async def _create_order(self, order_submit: CreateOrderSubmit, account_type: AccountType):
    order = await self._private_connectors[account_type].create_order(
        symbol=order_submit.symbol,
        side=order_submit.side,
        type=order_submit.type,
        amount=order_submit.amount
    )
    if order.success:
        self._cache._order_initialized(order)
        self._msgbus.send(endpoint="pending", msg=order)
```

## 3. 状态管理流

```
订单/持仓变化 → Cache更新 → MessageBus通知 → Strategy回调 → 风险检查
```

**详细流程**：
1. **状态变化**：订单状态或持仓发生变化
2. **缓存更新**：AsyncCache更新内存中的状态数据
3. **事件通知**：通过MessageBus通知相关组件
4. **策略回调**：触发Strategy中的状态变化回调
5. **风险评估**：进行实时风险检查和控制

## 4. 配置驱动流

```
Config文件 → Engine初始化 → 组件构建 → 连接建立 → 数据订阅
```

**配置示例**：
```python
config = Config(
    strategy_id="my_strategy",
    public_conn_config=[
        PublicConnectorConfig(
            exchange=ExchangeType.BINANCE,
            account_type=AccountType.BINANCE_SPOT
        )
    ],
    private_conn_config=[
        PrivateConnectorConfig(
            exchange=ExchangeType.BINANCE,
            account_type=AccountType.BINANCE_SPOT,
            api_key="your_api_key",
            api_secret="your_api_secret"
        )
    ]
)
```

## 5. 错误处理流

```
异常发生 → 错误捕获 → 日志记录 → 重试机制 → 状态恢复
```

**错误处理策略**：
- **连接错误**：自动重连机制
- **API错误**：指数退避重试
- **数据错误**：跳过并记录日志
- **订单错误**：状态回滚和通知

## 数据结构优化

### 1. 使用msgspec进行高效序列化

```python
from msgspec import Struct

class Trade(Struct, gc=False, frozen=True):
    exchange: ExchangeType
    symbol: str
    price: float
    size: float
    timestamp: int
```

### 2. 内存优化的数据容器

```python
class KlineList(list[Kline]):
    @property
    def df(self):
        # 延迟计算DataFrame
        data = {
            'timestamp': [kline.start for kline in self],
            'open': [kline.open for kline in self],
            'high': [kline.high for kline in self],
            'low': [kline.low for kline in self],
            'close': [kline.close for kline in self],
            'volume': [kline.volume for kline in self]
        }
        return pd.DataFrame(data)
```
