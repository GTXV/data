# NexusTrader 配置系统 (`config.py`) 设计与用法详解

`nexustrader/config.py` 文件是启动和定义任何 NexusTrader 交易策略的起点。它采用了一套基于 Python `dataclasses` 的声明式配置系统。开发者无需编写复杂的解析代码或管理外部文件（如 `.yaml` 或 `.json`），只需通过实例化一系列定义好的 Python 类，就能构建一个完整、清晰、且类型安全的配置对象。这个最终的 `Config` 对象将作为唯一的蓝图被传入 `Engine`，用以驱动整个交易系统的初始化和运行。

---

## 1. 核心设计原则

*   **声明式配置 (Declarative Configuration)**：你通过“声明”你的设置来定义系统行为，而不是通过编写命令式代码。例如，你创建一个 `LogConfig` 对象来定义日志，而不是调用多个函数来设置日志级别、格式等。

*   **组合优于继承 (Composition over Inheritance)**：顶层的 `Config` 对象是由多个更小、更专注的配置类（如 `BasicConfig`, `PublicConnectorConfig`）组合而成的。这种方式使得配置结构非常清晰和模块化。

*   **类型安全与IDE友好 (Type-Safety & IDE-Friendly)**：大量使用 `dataclasses`、类型提示（`Dict`, `List`）和枚举（`ExchangeType`, `AccountType`）使得配置过程享受到了现代IDE的全部优势，包括自动补全、参数提示和静态类型检查，极大地减少了配置错误。

*   **内置验证 (Built-in Validation)**：多个配置类利用 `__post_init__` 魔法方法，在对象创建后立即对传入的参数进行校验。例如，`Config` 类会自动检查你是否混用了模拟和真实的交易连接器，并在配置错误时立即抛出异常，实现了“快速失败”（Fail-Fast）原则。

---

## 2. 配置类的详细分解

以下是构成完整配置的核心组件类：

### `Config` (顶层配置对象)
这是所有配置的根容器，最终需要创建的就是这个类的实例。
*   `strategy_id` & `user_id`: 策略和用户的唯一标识符，用于数据库表和日志的命名空间，以隔离不同策略和用户的数据。
*   `strategy`: 你自己编写的策略类的实例。
*   `basic_config`: 一个字典，存储每个交易所的API密钥等基础信息。
*   `public_conn_config`: 一个字典，定义需要订阅哪些公开市场数据（如订单簿、成交信息）。
*   `private_conn_config`: 一个字典，定义用于交易和账户管理的私有连接。**这是决定实盘或模拟盘的关键**。
*   `storage_backend` & `db_path`: 配置数据持久化的方式（SQLite或PostgreSQL）和路径。
*   `cache_*`: 配置缓存和订单注册表的同步间隔、过期时间等性能相关参数。
*   `log_config`: 传入一个 `LogConfig` 实例来定制日志行为。
*   `is_mock`: **这个值通常不需要手动设置**。`Config` 的 `__post_init__` 方法会自动检测 `private_conn_config` 中是否使用了 `MockConnectorConfig`，并相应地设置此标志。

### `BasicConfig` (交易所基础配置)
存储连接交易所所需的最基本信息。
*   `api_key` & `secret`: 你的交易所API Key和Secret。
*   `testnet`:布尔值，设为 `True` 时将连接到交易所的测试网环境。
*   `passphrase`: 某些交易所（如 OKX）需要的额外密码。

### `PublicConnectorConfig` (公共数据连接)
定义一个公共数据的WebSocket连接。你需要为希望接收数据的每一种账户类型创建一个实例。
*   `account_type`: 关键字段，指定了要连接的服务器和频道类型，例如 `AccountType.BYBIT_LINEAR` 或 `AccountType.BINANCE_USDT_FUTURES`。
*   `custom_url`: 可选，用于连接非官方或代理的WebSocket地址。

### `PrivateConnectorConfig` (私有数据与交易连接 - 实盘)
定义一个用于真实交易的私有连接。
*   `account_type`: 指定要连接的账户类型，如 `AccountType.BYBIT_UNIFIED`。
*   `max_retries`, `delay_*`, `backoff_factor`: 配置下单失败后的自动重试逻辑，用于处理网络抖动或交易所临时错误。
*   `max_slippage`: 为市价单设置最大滑点保护。

### `MockConnectorConfig` (模拟连接 - 回测/模拟)
当你想进行模拟交易时，使用这个类代替 `PrivateConnectorConfig`。
*   `initial_balance`: 定义模拟账户的初始资金，例如 `{"USDT": 10000}`。
*   `account_type`: 必须是模拟账户类型，如 `AccountType.LINEAR_MOCK`。
*   `fee_rate`, `leverage`: 设置模拟交易的手续费率和杠杆。
*   `overwrite_balance`, `overwrite_position`: 是否在每次启动时覆盖数据库中已有的模拟余额和持仓。

### `LogConfig` (日志配置)
提供对日志系统的精细控制。
*   `level_stdout` & `level_file`: 分别设置控制台和文件日志的最低级别。
*   `directory` & `file_name`: 设置日志文件的存放位置和名称。
*   `max_file_size` & `max_backup_count`: 配置日志文件的滚动更新（rotation）。

---

## 3. 如何使用：示例代码

以下代码片段展示了如何构建一个完整的 `Config` 对象。

### 示例1：配置一个Bybit永续合约实盘策略

```python
from nexustrader.config import (
    Config,
    BasicConfig,
    PublicConnectorConfig,
    PrivateConnectorConfig,
    LogConfig,
)
from nexustrader.constants import ExchangeType, AccountType
from my_strategies import MyBybitStrategy  # 假设这是你写的策略

# 1. 实例化你的策略
strategy_instance = MyBybitStrategy()

# 2. 配置交易所API密钥 (建议从环境变量或安全的地方加载)
bybit_basic_config = BasicConfig(
    api_key="YOUR_BYBIT_API_KEY",
    secret="YOUR_BYBIT_SECRET_KEY",
    testnet=False,  # 使用实盘
)

# 3. 配置公共数据连接 (订阅U本位合约的行情)
bybit_public_conn = PublicConnectorConfig(
    account_type=AccountType.BYBIT_LINEAR,  # U本位合约
)

# 4. 配置私有交易连接 (使用统一交易账户)
bybit_private_conn = PrivateConnectorConfig(
    account_type=AccountType.BYBIT_UNIFIED,
)

# 5. (可选) 自定义日志配置
log_config = LogConfig(
    level_stdout="INFO",
    level_file="DEBUG",
    file_name="my_bybit_strategy.log",
)

# 6. 组装最终的 Config 对象
config = Config(
    strategy_id="MY_AWESOME_STRATEGY",
    user_id="USER_001",
    strategy=strategy_instance,
    basic_config={
        ExchangeType.BYBIT: bybit_basic_config,
    },
    public_conn_config={
        ExchangeType.BYBIT: [bybit_public_conn],
    },
    private_conn_config={
        ExchangeType.BYBIT: [bybit_private_conn],
    },
    log_config=log_config,
    storage_backend="SQLITE",
    db_path=".keys/my_strategy_cache.db",
)

# 7. 将 config 传入 Engine
# from nexustrader.engine import Engine
# engine = Engine(config)
# engine.start()
```

### 示例2：配置一个模拟盘策略

注意 `private_conn_config` 的变化。

```python
from nexustrader.config import Config, BasicConfig, PublicConnectorConfig, MockConnectorConfig
from nexustrader.constants import ExchangeType, AccountType
from my_strategies import MyBybitStrategy

strategy_instance = MyBybitStrategy()

# 在模拟盘中，BasicConfig 不是必须的，但为了结构完整可以保留
bybit_basic_config = BasicConfig(testnet=True)

# 公共连接保持不变，我们仍然需要真实的行情数据
bybit_public_conn = PublicConnectorConfig(account_type=AccountType.BYBIT_LINEAR)

# *** 关键变化：使用 MockConnectorConfig ***
bybit_mock_conn = MockConnectorConfig(
    account_type=AccountType.LINEAR_MOCK,  # 使用模拟线性合约账户
    initial_balance={"USDT": 50000},      # 设置初始资金
    fee_rate=0.0006,                      # 模拟手续费
    leverage=10.0,                        # 模拟杠杆
)

# 组装 Config 对象
config = Config(
    strategy_id="MY_MOCK_STRATEGY",
    user_id="USER_001",
    strategy=strategy_instance,
    basic_config={
        ExchangeType.BYBIT: bybit_basic_config,
    },
    public_conn_config={
        ExchangeType.BYBIT: [bybit_public_conn],
    },
    # 使用模拟连接器配置
    private_conn_config={
        ExchangeType.BYBIT: [bybit_mock_conn],
    },
)

# 当这个 config 被传入 Engine 时，engine.is_mock 会被自动设为 True
```