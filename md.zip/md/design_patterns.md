# 设计模式详细分析

## 1. Builder模式 - Engine构建

**应用场景**：Engine类的初始化过程

**实现代码**：
```python
class Engine:
    def _build(self):
        self._public_connector_check()
        self._build_public_connectors()
        self._build_private_connectors()
        self._build_exchanges()
        self._build_ems()
        self._build_oms()
        
    def _build_public_connectors(self):
        # 根据配置构建公开连接器
        for conn_config in self._config.public_conn_config:
            if conn_config.exchange == ExchangeType.BINANCE:
                connector = BinancePublicConnector(...)
            elif conn_config.exchange == ExchangeType.OKX:
                connector = OkxPublicConnector(...)
            self._public_connectors[conn_config.account_type] = connector
```

**优势**：
- 分步骤构建复杂系统
- 可控制构建顺序
- 易于扩展新的构建步骤

## 2. Abstract Factory模式 - 交易所适配

**应用场景**：不同交易所连接器的创建

**实现示例**：
```python
class ExchangeFactory:
    @staticmethod
    def create_connectors(exchange_type: ExchangeType):
        if exchange_type == ExchangeType.BINANCE:
            return BinancePublicConnector(), BinancePrivateConnector()
        elif exchange_type == ExchangeType.OKX:
            return OkxPublicConnector(), OkxPrivateConnector()
        elif exchange_type == ExchangeType.BYBIT:
            return BybitPublicConnector(), BybitPrivateConnector()
```

**优势**：
- 统一创建接口
- 易于添加新交易所支持
- 运行时切换交易所实现

## 3. Template Method模式 - 策略框架

**应用场景**：Strategy基类定义策略执行模板

**实现代码**：
```python
class Strategy:
    def _on_trade(self, trade: Trade):
        self.on_trade(trade)  # 调用子类实现
        self._update_indicators(trade)  # 通用处理
        
    def _on_kline(self, kline: Kline):
        self.on_kline(kline)  # 子类实现
        self._subscriptions_ready[kline.interval.value].input(kline)
        
    # 子类需要实现的抽象方法
    def on_start(self):
        pass
        
    def on_trade(self, trade: Trade):
        pass
        
    def on_kline(self, kline: Kline):
        pass
```

**优势**：
- 定义算法骨架
- 子类实现具体步骤
- 代码复用和一致性

## 4. Observer模式 - 事件系统

**应用场景**：MessageBus消息分发

**实现代码**：
```python
class MessageBus:
    def __init__(self):
        self._handlers = defaultdict(list)
        
    def register(self, endpoint: str, handler: Callable):
        self._handlers[endpoint].append(handler)
        
    def send(self, endpoint: str, msg: Any):
        for handler in self._handlers[endpoint]:
            try:
                handler(msg)
            except Exception as e:
                self._log.error(f"Handler error: {e}")
```

**优势**：
- 松耦合的事件通知
- 支持多个观察者
- 动态订阅和取消订阅

## 5. Command模式 - 订单系统

**应用场景**：订单提交和执行

**实现代码**：
```python
class ExecutionManagementSystem:
    async def _submit_order(self, order: OrderSubmit, submit_type: SubmitType):
        # Command模式：将订单请求封装为命令对象
        account_type = self._infer_account_type(order.symbol)
        await self._order_submit_queues[account_type].put((order, submit_type))
        
    async def _handle_submit_order(self, account_type, queue):
        submit_handlers = {
            SubmitType.CREATE: self._create_order,
            SubmitType.CANCEL: self._cancel_order,
            SubmitType.MODIFY: self._modify_order,
            SubmitType.TWAP: self._create_twap_order,
        }
        
        while True:
            order_submit, submit_type = await queue.get()
            handler = submit_handlers[submit_type]
            await handler(order_submit, account_type)
```

**优势**：
- 请求与执行解耦
- 支持队列和批处理
- 可记录和撤销操作

## 6. Proxy模式 - API包装

**应用场景**：ApiProxy包装异步API调用

**实现代码**：
```python
class ApiProxy:
    def __init__(self, api_client: ApiClient, task_manager: TaskManager):
        self._api_client = api_client
        self._task_manager = task_manager

    def __getattr__(self, name):
        if not hasattr(self._api_client, name):
            raise AttributeError(f"ApiClient has no attribute '{name}'")

        api_method = getattr(self._api_client, name)
        if not callable(api_method):
            return api_method

        def sync_wrapper(*args, **kwargs):
            return self._task_manager.run_sync(api_method(*args, **kwargs))

        return sync_wrapper
```

**优势**：
- 透明的同步/异步转换
- 统一的接口访问
- 可添加缓存和重试逻辑
