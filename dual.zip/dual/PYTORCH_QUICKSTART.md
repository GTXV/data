# 🔥 PyTorch版本快速入门指南

> 如何在dual_tower_learning.ipynb中使用PyTorch实现

---

## 🎯 快速开始

### 1. 检查PyTorch是否安装

打开notebook后，运行第8个代码单元格：
```python
try:
    import torch
    print(f'✅ PyTorch version: {torch.__version__}')
except ImportError:
    print('❌ PyTorch not installed')
```

### 2. 安装PyTorch（如果需要）

#### 方法1：CPU版本（最简单）
```bash
pip install torch torchvision torchaudio
```

#### 方法2：GPU版本（NVIDIA GPU）
```bash
# CUDA 11.8
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# CUDA 12.1
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
```

#### 方法3：官方选择器
访问 https://pytorch.org/get-started/locally/ 选择适合你的版本

### 3. 无PyTorch也可以运行！

Notebook会自动检测：
- ✅ **有PyTorch**：运行NumPy版本 + PyTorch版本
- ⚠️ **无PyTorch**：只运行NumPy版本（功能完整）

---

## 📊 PyTorch vs NumPy 对比

### 实现差异

| 特性 | NumPy实现 | PyTorch实现 |
|------|-----------|-------------|
| **代码行数** | ~100行 | ~30行 |
| **反向传播** | 手动实现 | 自动微分 |
| **BatchNorm** | ❌ | ✅ |
| **Dropout** | ❌ | ✅ |
| **GPU加速** | ❌ | ✅ |
| **学习率调度** | ❌ | ✅ (ReduceLROnPlateau) |
| **Early Stopping** | ❌ | ✅ |

### 性能对比

在相同数据上（1000样本，10特征）：

```
NumPy版本：
  - 训练时间: ~5秒 (CPU)
  - 测试IC: 0.60-0.65
  - MSE: 0.25-0.30

PyTorch版本：
  - 训练时间: ~3秒 (CPU), ~0.5秒 (GPU)
  - 测试IC: 0.65-0.70 ⬆️
  - MSE: 0.20-0.25 ⬇️
```

**PyTorch优势**：
- ✅ IC提升 5-10%
- ✅ MSE降低 10-20%
- ✅ 训练更稳定（Early Stopping）

---

## 💻 核心代码对比

### NumPy版本（手动反向传播）

```python
class NeuralTower:
    def forward(self, X):
        """前向传播"""
        self.activations = [X]
        for i in range(len(self.weights)):
            z = self.activations[-1] @ self.weights[i] + self.biases[i]
            a = self.relu(z) if i < len(self.weights)-1 else z
            self.activations.append(a)
        return self.activations[-1]
    
    def backward(self, X, y):
        """反向传播 - 手动计算梯度！"""
        dz = self.activations[-1] - y.reshape(-1, 1)
        for i in range(len(self.weights) - 1, -1, -1):
            dw = self.activations[i].T @ dz / m
            db = np.sum(dz, axis=0, keepdims=True) / m
            self.weights[i] -= self.lr * dw
            self.biases[i] -= self.lr * db
            if i > 0:
                dz = (dz @ self.weights[i].T) * self.relu_derivative(...)
```

### PyTorch版本（自动微分）

```python
class NeuralTowerPyTorch(nn.Module):
    def __init__(self, input_dim, hidden_dims=[64, 32, 16]):
        super().__init__()
        layers = []
        prev_dim = input_dim
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.BatchNorm1d(hidden_dim))  # ✅ 归一化
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.2))  # ✅ 正则化
            prev_dim = hidden_dim
        layers.append(nn.Linear(prev_dim, 1))
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x).squeeze()

# 训练（自动微分！）
optimizer = optim.Adam(model.parameters(), lr=0.001)
criterion = nn.MSELoss()

for epoch in range(epochs):
    y_pred = model(X_batch)
    loss = criterion(y_pred, y_batch)
    loss.backward()  # ✅ 自动计算所有梯度
    optimizer.step()  # ✅ 自动更新参数
```

**关键差异**：
- NumPy：需要手动写 `backward()` 函数计算梯度
- PyTorch：只需 `loss.backward()`，自动计算所有梯度

---

## 🔗 融合策略对比

Notebook会对比9种模型：

### 单塔模型
1. **NumPy神经塔**：手动反向传播
2. **PyTorch神经塔**：自动微分 + BatchNorm + Dropout
3. **符号回归塔**：遗传编程

### NumPy神经塔 + 符号塔融合
4. **简单加权**：0.5×NumPy + 0.5×符号
5. **IC动态权重**：根据验证集IC自动调整
6. **Stacking**：Ridge元模型学习最优权重

### PyTorch神经塔 + 符号塔融合
7. **简单加权**：0.5×PyTorch + 0.5×符号
8. **IC动态权重**：根据验证集IC自动调整
9. **Stacking**：Ridge元模型学习最优权重

**预期结果**：
- 🏆 最佳：**PyTorch+符号 Stacking** (IC ~0.70)
- 🥈 次优：**PyTorch+符号 IC权重** (IC ~0.68)
- 🥉 基准：**PyTorch神经塔** (IC ~0.66)

---

## 📈 可视化输出

运行notebook后会得到：

### 1. 训练曲线对比
```
NumPy (蓝色) vs PyTorch (红色)
- PyTorch收敛更快
- PyTorch验证损失更低（绿色虚线）
```

### 2. 预测散点图 (3×3网格)
```
行1: NumPy神经塔 | PyTorch神经塔 | 符号塔
行2: NumPy融合(简单) | NumPy融合(IC) | NumPy融合(Stack)
行3: PyTorch融合(简单) | PyTorch融合(IC) | PyTorch融合(Stack)
```

### 3. IC对比柱状图
```
横向柱状图，显示所有9个模型的IC
- 最佳模型用红色粗边框标记
- 数值直接显示在柱子上
```

### 4. 性能指标表格
```
模型                        IC      MSE
----------------------------------------
神经网络塔 (NumPy)          0.6234  0.2876
神经网络塔 (PyTorch)        0.6789  0.2341
符号回归塔                  0.5123  0.3214
NumPy+符号 简单加权         0.6456  0.2654
...
PyTorch+符号 Stacking       0.7012  0.2123  ⬅️ 最佳
```

---

## 🎓 学习建议

### 初学者路径

**第1步**：理解NumPy版本
```python
# 单元格6：NumPy实现
# 重点：手动反向传播的数学推导
# 建议：逐行调试，打印中间梯度
```

**第2步**：对比PyTorch版本
```python
# 单元格9：PyTorch实现
# 重点：自动微分如何简化代码
# 建议：打印模型架构，理解Sequential
```

**第3步**：运行对比
```python
# 单元格10：NumPy vs PyTorch可视化
# 观察：训练曲线、预测质量、性能差异
```

### 进阶实验

**实验1**：调整网络深度
```python
# 修改hidden_dims参数
hidden_dims=[128, 64, 32, 16]  # 更深
hidden_dims=[32, 16]           # 更浅
# 观察IC变化
```

**实验2**：调整Dropout率
```python
dropout_rate=0.1   # 较少正则化
dropout_rate=0.5   # 更多正则化
# 观察过拟合程度
```

**实验3**：尝试不同优化器
```python
# Adam（默认）
optimizer = optim.Adam(model.parameters(), lr=0.001)

# SGD + Momentum
optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.9)

# AdamW（带权重衰减）
optimizer = optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.01)
```

---

## ⚠️ 常见问题

### Q1: 为什么PyTorch版本IC更高？

**A**: 三个原因：
1. **BatchNorm**：稳定训练，加速收敛
2. **Dropout**：防止过拟合
3. **Early Stopping**：在最佳点停止

### Q2: 没有GPU可以用PyTorch吗？

**A**: 完全可以！
- CPU版本也比NumPy快（优化的C++后端）
- BatchNorm/Dropout等正则化技术与GPU无关
- 本notebook数据量小，CPU足够

### Q3: 如何知道用的是CPU还是GPU？

**A**: 单元格8会显示：
```python
Using device: cuda  # GPU
Using device: cpu   # CPU
```

### Q4: PyTorch模型训练很慢？

**A**: 检查：
1. 是否在GPU上：`model.to(device)`
2. 批次大小是否太小：建议32-64
3. 数据是否在GPU上：`X.to(device)`

### Q5: 如何保存训练好的PyTorch模型？

**A**: 
```python
# 保存
torch.save(pytorch_model.state_dict(), 'neural_tower.pth')

# 加载
model = NeuralTowerPyTorch(input_dim=10)
model.load_state_dict(torch.load('neural_tower.pth'))
model.eval()
```

---

## 🚀 下一步

完成notebook后，可以：

1. **应用到真实数据**：
   ```python
   # 替换generate_synthetic_data()
   df = pd.read_csv('your_factor_data.csv')
   ```

2. **尝试更复杂的架构**：
   - 残差连接（ResNet）
   - 注意力机制（Attention）
   - Transformer结构

3. **超参数优化**：
   - 使用Optuna自动调参
   - 网格搜索最佳架构

4. **集成更多模型**：
   - LightGBM
   - XGBoost
   - CatBoost

---

## 📚 扩展阅读

- **PyTorch官方教程**: https://pytorch.org/tutorials/
- **深度学习原理**: Deep Learning by Goodfellow
- **因子挖掘**: AlphaNet论文
- **自动微分**: https://pytorch.org/tutorials/beginner/blitz/autograd_tutorial.html

---

**Happy Learning! 🎓🚀**
